function [primer_sequences ] = design_primers_NEW( sequence, min_Tm, NUM_PRIMERS, misprime_mode, tag );
% 
% (C) Rhiju Das, 2013

fprintf( '\n design_primers_NEW has been renamed to design_primers. Use design_primers instead!\n' )

